/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { HailParameters, PresetScenario } from './types';
import { PRESET_SCENARIOS } from './data/presets';
import { calculateHailSimulation } from './utils/physics';
import { CloudCanvas } from './components/CloudCanvas';
import { ParameterPanel } from './components/ParameterPanel';
import { HailInspector } from './components/HailInspector';
import { ImpactReport } from './components/ImpactReport';
import { ScienceGuide } from './components/ScienceGuide';
import { 
  CloudLightning, 
  Layers, 
  ShieldAlert, 
  BookOpen, 
  Sliders, 
  RotateCcw, 
  Zap, 
  Activity,
  Droplets,
  Wind
} from 'lucide-react';

export default function App() {
  // Initial default scenario (Golfball storm)
  const [params, setParams] = useState<HailParameters>(PRESET_SCENARIOS[0].params);
  const [activePresetId, setActivePresetId] = useState<string | null>(PRESET_SCENARIOS[0].id);
  const [activeTab, setActiveTab] = useState<'simulation' | 'inspector' | 'impact' | 'science'>('simulation');

  // Compute simulation physics whenever parameters change
  const simResult = useMemo(() => {
    return calculateHailSimulation(params);
  }, [params]);

  const handleParamChange = (newParams: HailParameters) => {
    setParams(newParams);
    setActivePresetId(null); // customized
  };

  const handleApplyPreset = (preset: PresetScenario) => {
    setParams(preset.params);
    setActivePresetId(preset.id);
  };

  const handleReset = () => {
    setParams(PRESET_SCENARIOS[0].params);
    setActivePresetId(PRESET_SCENARIOS[0].id);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-blue-600 selection:text-white">
      {/* Top Main Navigation Header */}
      <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 via-sky-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/20 border border-blue-400/30">
              <CloudLightning className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-tight text-white">
                  우박 생성 과정 시뮬레이터
                </h1>
                <span className="hidden sm:inline-block text-[10px] px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/20 font-mono">
                  Hail Dynamics v2.0
                </span>
              </div>
              <p className="text-xs text-slate-400">
                대기 기상 변수 제어 및 적란운 내 우박 성장·층상 구조 실시간 탐구
              </p>
            </div>
          </div>

          {/* Quick Outcome Result Header Pill */}
          <div className="flex items-center gap-2.5 bg-slate-950/80 border border-slate-800 rounded-full px-3.5 py-1.5 shadow-inner">
            <span className="text-xs text-slate-400">결과:</span>
            {simResult.finalDiameterMm > 0 ? (
              <div className="flex items-center gap-2 flex-wrap text-xs">
                <span className="font-bold text-amber-400 font-mono">
                  Ø {simResult.finalDiameterMm}mm ({simResult.sizeClassNameKo})
                </span>
                <span className="text-slate-600">|</span>
                <span className="text-sky-300 font-mono">
                  {simResult.terminalVelocityKmh} km/h
                </span>
                <span className="text-slate-600">|</span>
                <span className="font-bold text-rose-400 font-mono">
                  🍉 수박 {simResult.watermelonImpact.watermelonsBroken}개 파괴
                </span>
              </div>
            ) : (
              <span className="text-xs font-bold text-rose-400 flex items-center gap-1">
                <Droplets className="w-3.5 h-3.5" />
                지상 융해 (비로 소멸)
              </span>
            )}
          </div>
        </div>

        {/* Tab Navigation Menu */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex gap-2 border-t border-slate-800/60 overflow-x-auto py-1">
          <button
            id="tab-btn-simulation"
            onClick={() => setActiveTab('simulation')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'simulation'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            대기 시뮬레이션 & 변수 제어
          </button>

          <button
            id="tab-btn-inspector"
            onClick={() => setActiveTab('inspector')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'inspector'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            우박 층상 단면 & 밀도 분석
            <span className="text-[10px] px-1.5 py-0.2 bg-slate-900 rounded-full font-mono">
              {simResult.layers.length}층
            </span>
          </button>

          <button
            id="tab-btn-impact"
            onClick={() => setActiveTab('impact')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'impact'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            지상 충격 & 수박 파괴 시뮬레이션
            <span className="text-[10px] px-1.5 py-0.2 bg-rose-950 text-rose-300 border border-rose-800/60 rounded-full font-mono">
              🍉 {simResult.watermelonImpact.watermelonsBroken}개
            </span>
          </button>

          <button
            id="tab-btn-science"
            onClick={() => setActiveTab('science')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'science'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            우박 과학 원리
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 flex flex-col gap-6">
        {activeTab === 'simulation' && (
          <div className="flex flex-col gap-6">
            {/* Live Interactive Cloud Canvas */}
            <CloudCanvas
              params={params}
              simResult={simResult}
              onReset={handleReset}
            />

            {/* Variable Parameter Controller */}
            <ParameterPanel
              params={params}
              onChangeParams={handleParamChange}
              onApplyPreset={handleApplyPreset}
              activePresetId={activePresetId}
            />
          </div>
        )}

        {activeTab === 'inspector' && (
          <HailInspector simResult={simResult} />
        )}

        {activeTab === 'impact' && (
          <ImpactReport simResult={simResult} />
        )}

        {activeTab === 'science' && (
          <ScienceGuide />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>대기역학 및 구름물리학 기반 우박 생성 시뮬레이터 (Hail Dynamics Simulator)</span>
          <span className="text-slate-600">
            상승기류(Updraft) • 과냉각수(SLW) • 동결고도 • 건성/습성 빙결 층상화
          </span>
        </div>
      </footer>
    </div>
  );
}
