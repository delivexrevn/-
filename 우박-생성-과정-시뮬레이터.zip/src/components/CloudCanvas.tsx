import React, { useEffect, useRef, useState, useCallback } from 'react';
import { HailParameters, HailSimulationResult, HailTrajectoryPoint } from '../types';
import { Play, Pause, RotateCcw, FastForward, Eye, Layers, Wind, Sparkles, ZoomIn, ZoomOut } from 'lucide-react';

interface CloudCanvasProps {
  params: HailParameters;
  simResult: HailSimulationResult;
  onReset: () => void;
}

export const CloudCanvas: React.FC<CloudCanvasProps> = ({ params, simResult, onReset }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [showWindVectors, setShowWindVectors] = useState<boolean>(true);
  const [showTempLines, setShowTempLines] = useState<boolean>(true);
  const [showTrajectoryTrail, setShowTrajectoryTrail] = useState<boolean>(true);
  const [focusZoom, setFocusZoom] = useState<boolean>(false);

  const trajectory = simResult.trajectory;
  const currentPoint: HailTrajectoryPoint | undefined = trajectory[currentStepIndex] || trajectory[trajectory.length - 1];

  // Animation frame loop
  const animFrameRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(performance.now());
  const progressAccumRef = useRef<number>(0);

  // Restart animation when params change or reset is triggered
  useEffect(() => {
    setCurrentStepIndex(0);
    setIsPlaying(true);
    progressAccumRef.current = 0;
  }, [simResult]);

  useEffect(() => {
    const animate = (time: number) => {
      const delta = (time - lastTimeRef.current) / 1000;
      lastTimeRef.current = time;

      if (isPlaying && trajectory.length > 0) {
        // Step progress depends on playbackSpeed
        // trajectory points are every 1 sec simulation time
        const stepsPerSec = 8 * playbackSpeed;
        progressAccumRef.current += stepsPerSec * delta;

        if (progressAccumRef.current >= 1) {
          const advanceBy = Math.floor(progressAccumRef.current);
          progressAccumRef.current -= advanceBy;

          setCurrentStepIndex((prev) => {
            const next = prev + advanceBy;
            if (next >= trajectory.length - 1) {
              setIsPlaying(false);
              return trajectory.length - 1;
            }
            return next;
          });
        }
      }

      animFrameRef.current = requestAnimationFrame(animate);
    };

    lastTimeRef.current = performance.now();
    animFrameRef.current = requestAnimationFrame(animate);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isPlaying, playbackSpeed, trajectory.length]);

  // Canvas drawing routine
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Padding for UI margins
    const leftMargin = 55;
    const rightMargin = 20;
    const topMargin = 30;
    const bottomMargin = 45;
    const plotW = width - leftMargin - rightMargin;
    const plotH = height - topMargin - bottomMargin;

    // Helper coordinate transforms
    const maxAlt = params.cloudTopAltitude;
    const altToY = (altKm: number) => topMargin + plotH * (1 - altKm / maxAlt);
    const normXToScreen = (normX: number) => leftMargin + plotW * normX;

    // 1. Sky & Atmosphere Background Gradient
    const skyGrad = ctx.createLinearGradient(0, topMargin, 0, topMargin + plotH);
    skyGrad.addColorStop(0, '#0f172a');    // -50°C deep stratosphere navy
    skyGrad.addColorStop(0.35, '#1e293b'); // high troposphere
    skyGrad.addColorStop(0.7, '#334155');  // mid freezing zone
    skyGrad.addColorStop(1, '#f1f5f9');    // warm ground haze
    ctx.fillStyle = skyGrad;
    ctx.fillRect(leftMargin, topMargin, plotW, plotH);

    // 2. Altitude & Temperature Grid Lines
    if (showTempLines) {
      // 0°C Freezing Line
      const freezeY = altToY(params.freezingLevel);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(leftMargin, freezeY);
      ctx.lineTo(leftMargin + plotW, freezeY);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = '#38bdf8';
      ctx.font = '11px sans-serif';
      ctx.fillText(`0°C 동결선 (${params.freezingLevel.toFixed(1)}km)`, leftMargin + 8, freezeY - 5);

      // -20°C Rapid Freezing Line (Rime Zone)
      const lapse = (params.surfaceTemp - params.cloudTopTemp) / params.cloudTopAltitude;
      const alt20 = (params.surfaceTemp - (-20)) / lapse;
      if (alt20 > 0 && alt20 < maxAlt) {
        const y20 = altToY(alt20);
        ctx.strokeStyle = '#818cf8';
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 4]);
        ctx.beginPath();
        ctx.moveTo(leftMargin, y20);
        ctx.lineTo(leftMargin + plotW, y20);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.fillStyle = '#c7d2fe';
        ctx.font = '10px sans-serif';
        ctx.fillText(`-20°C 급속빙결 구역 (${alt20.toFixed(1)}km)`, leftMargin + 8, y20 - 4);
      }

      // -40°C Homogeneous Nucleation
      const alt40 = (params.surfaceTemp - (-40)) / lapse;
      if (alt40 > 0 && alt40 < maxAlt) {
        const y40 = altToY(alt40);
        ctx.strokeStyle = '#93c5fd';
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 4]);
        ctx.beginPath();
        ctx.moveTo(leftMargin, y40);
        ctx.lineTo(leftMargin + plotW, y40);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.fillStyle = '#bae6fd';
        ctx.font = '10px sans-serif';
        ctx.fillText(`-40°C 균질빙결 한계 (${alt40.toFixed(1)}km)`, leftMargin + 8, y40 - 4);
      }
    }

    // 3. Realistic Cumulonimbus Cloud Contour
    ctx.save();
    ctx.beginPath();
    const cloudBaseY = altToY(Math.min(1.2, params.freezingLevel * 0.4));
    const cloudTopY = altToY(params.cloudTopAltitude);
    
    // Draw anvil top and billowing storm shape
    const midX = leftMargin + plotW * 0.5;
    ctx.moveTo(leftMargin + plotW * 0.08, cloudTopY + 12);
    // Anvil spread top
    ctx.bezierCurveTo(
      leftMargin + plotW * 0.2, cloudTopY - 10,
      leftMargin + plotW * 0.8, cloudTopY - 10,
      leftMargin + plotW * 0.92, cloudTopY + 18
    );
    // Right wall billowing convection
    ctx.bezierCurveTo(
      leftMargin + plotW * 0.95, cloudTopY + 70,
      leftMargin + plotW * 0.85, (cloudTopY + cloudBaseY) * 0.45,
      leftMargin + plotW * 0.88, (cloudTopY + cloudBaseY) * 0.7
    );
    // Down to right base
    ctx.bezierCurveTo(
      leftMargin + plotW * 0.9, cloudBaseY - 15,
      leftMargin + plotW * 0.75, cloudBaseY,
      leftMargin + plotW * 0.7, cloudBaseY
    );
    // Flat dark base
    ctx.lineTo(leftMargin + plotW * 0.3, cloudBaseY);
    // Up along left wall
    ctx.bezierCurveTo(
      leftMargin + plotW * 0.25, cloudBaseY,
      leftMargin + plotW * 0.12, (cloudTopY + cloudBaseY) * 0.7,
      leftMargin + plotW * 0.15, (cloudTopY + cloudBaseY) * 0.45
    );
    ctx.bezierCurveTo(
      leftMargin + plotW * 0.06, cloudTopY + 70,
      leftMargin + plotW * 0.05, cloudTopY + 25,
      leftMargin + plotW * 0.08, cloudTopY + 12
    );
    ctx.closePath();

    // Cloud Fill Gradient
    const cloudGrad = ctx.createLinearGradient(0, cloudTopY, 0, cloudBaseY);
    cloudGrad.addColorStop(0, 'rgba(255, 255, 255, 0.45)');
    cloudGrad.addColorStop(0.4, 'rgba(203, 213, 225, 0.35)');
    cloudGrad.addColorStop(0.85, 'rgba(71, 85, 105, 0.55)');
    cloudGrad.addColorStop(1, 'rgba(30, 41, 59, 0.75)');
    ctx.fillStyle = cloudGrad;
    ctx.fill();

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.restore();

    // 4. Updraft Vector Arrows & Thermal Core
    if (showWindVectors) {
      const timeOffset = (Date.now() / 1000) % 2;
      const arrowCount = 7;
      
      for (let i = 0; i < arrowCount; i++) {
        const normX = 0.32 + (i / (arrowCount - 1)) * 0.36;
        const xPos = normXToScreen(normX);
        const distFromCenter = Math.abs(normX - 0.5);
        const speedRatio = Math.max(0.2, 1 - (distFromCenter / 0.25));

        // Upward rising arrows
        for (let alt = 1.5; alt < params.cloudTopAltitude; alt += 2.2) {
          const waveAlt = alt + ((timeOffset * 2.5 * speedRatio) % 2.2);
          if (waveAlt < params.cloudTopAltitude) {
            const yPos = altToY(waveAlt);
            const arrowLen = 14 + speedRatio * 16 * (params.updraftVelocity / 35);

            ctx.save();
            ctx.strokeStyle = `rgba(251, 146, 60, ${0.35 + speedRatio * 0.45})`;
            ctx.fillStyle = `rgba(251, 146, 60, ${0.45 + speedRatio * 0.45})`;
            ctx.lineWidth = 1.5 + speedRatio * 1.5;

            ctx.beginPath();
            ctx.moveTo(xPos, yPos);
            ctx.lineTo(xPos, yPos - arrowLen);
            ctx.stroke();

            // Arrow head
            ctx.beginPath();
            ctx.moveTo(xPos - 3, yPos - arrowLen + 5);
            ctx.lineTo(xPos, yPos - arrowLen);
            ctx.lineTo(xPos + 3, yPos - arrowLen + 5);
            ctx.stroke();
            ctx.restore();
          }
        }
      }

      // Edge Downdrafts
      [-1, 1].forEach((dir) => {
        const normX = dir === -1 ? 0.18 : 0.82;
        const xPos = normXToScreen(normX);
        for (let alt = params.cloudTopAltitude * 0.7; alt > 1.0; alt -= 3.0) {
          const waveAlt = alt - ((timeOffset * 2.0) % 3.0);
          if (waveAlt > 0) {
            const yPos = altToY(waveAlt);
            ctx.save();
            ctx.strokeStyle = 'rgba(96, 165, 250, 0.45)';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(xPos, yPos);
            ctx.lineTo(xPos, yPos + 16);
            ctx.stroke();

            ctx.beginPath();
            ctx.moveTo(xPos - 3, yPos + 11);
            ctx.lineTo(xPos, yPos + 16);
            ctx.lineTo(xPos + 3, yPos + 11);
            ctx.stroke();
            ctx.restore();
          }
        }
      });
    }

    // 5. Ground Line & Landscape Illustration
    const groundY = altToY(0);
    ctx.fillStyle = '#15803d'; // Green grass
    ctx.fillRect(leftMargin, groundY, plotW, bottomMargin);

    // Ground details (Road, House, Car)
    ctx.fillStyle = '#475569'; // Road
    ctx.fillRect(leftMargin + plotW * 0.4, groundY + 12, plotW * 0.45, 14);

    // Simple House
    const houseX = leftMargin + plotW * 0.2;
    const houseY = groundY - 14;
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(houseX, houseY, 18, 14);
    ctx.fillStyle = '#ef4444'; // Red roof
    ctx.beginPath();
    ctx.moveTo(houseX - 3, houseY);
    ctx.lineTo(houseX + 9, houseY - 10);
    ctx.lineTo(houseX + 21, houseY);
    ctx.closePath();
    ctx.fill();

    // Car on road
    const carX = leftMargin + plotW * 0.58;
    const carY = groundY + 5;
    ctx.fillStyle = '#3b82f6';
    ctx.fillRect(carX, carY, 20, 7);
    ctx.fillRect(carX + 4, carY - 5, 12, 5);
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(carX + 5, carY + 8, 3, 0, Math.PI * 2);
    ctx.arc(carX + 16, carY + 8, 3, 0, Math.PI * 2);
    ctx.fill();

    // 6. Trajectory Path of Hailstone
    if (showTrajectoryTrail && currentStepIndex > 0) {
      ctx.save();
      for (let i = 1; i <= currentStepIndex; i++) {
        const p0 = trajectory[i - 1];
        const p1 = trajectory[i];
        const x0 = normXToScreen(p0.xNormalized);
        const y0 = altToY(p0.altitudeKm);
        const x1 = normXToScreen(p1.xNormalized);
        const y1 = altToY(p1.altitudeKm);

        ctx.beginPath();
        ctx.moveTo(x0, y0);
        ctx.lineTo(x1, y1);

        // Color coding by growth regime
        if (p1.currentMode === 'dry_rime') {
          ctx.strokeStyle = 'rgba(253, 224, 71, 0.9)'; // Yellow-gold for dry rime
          ctx.lineWidth = 3;
        } else if (p1.currentMode === 'wet_glaze') {
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.95)'; // Cyan for wet glaze
          ctx.lineWidth = 3.5;
        } else if (p1.currentMode === 'melting') {
          ctx.strokeStyle = 'rgba(244, 63, 94, 0.9)'; // Red-pink for melting
          ctx.lineWidth = 2.5;
        } else {
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.lineWidth = 2;
        }
        ctx.stroke();
      }
      ctx.restore();
    }

    // 7. Draw Current Hailstone Marker & Halo HUD
    if (currentPoint) {
      const curX = normXToScreen(currentPoint.xNormalized);
      const curY = altToY(currentPoint.altitudeKm);

      // Visual scaled radius on canvas (min 5px, max 26px for visibility)
      const visualRadius = Math.max(5, Math.min(26, 4 + currentPoint.diameterMm * 0.28));

      ctx.save();

      // Pulsing outer halo
      const pulse = (Math.sin(Date.now() / 150) + 1) * 3;
      ctx.beginPath();
      ctx.arc(curX, curY, visualRadius + pulse + 4, 0, Math.PI * 2);
      ctx.strokeStyle = currentPoint.currentMode === 'melting' 
        ? 'rgba(244, 63, 94, 0.4)' 
        : 'rgba(56, 189, 248, 0.5)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Hailstone sphere rendering
      const hailGrad = ctx.createRadialGradient(
        curX - visualRadius * 0.3,
        curY - visualRadius * 0.3,
        visualRadius * 0.1,
        curX,
        curY,
        visualRadius
      );

      if (currentPoint.currentMode === 'dry_rime') {
        // Opaque white with slight gold sheen
        hailGrad.addColorStop(0, '#ffffff');
        hailGrad.addColorStop(0.7, '#fef08a');
        hailGrad.addColorStop(1, '#ca8a04');
      } else if (currentPoint.currentMode === 'wet_glaze') {
        // Clear glassy icy cyan
        hailGrad.addColorStop(0, '#ffffff');
        hailGrad.addColorStop(0.5, '#7dd3fc');
        hailGrad.addColorStop(1, '#0284c7');
      } else if (currentPoint.currentMode === 'melting') {
        // Droplet / melting pinkish water coat
        hailGrad.addColorStop(0, '#ffffff');
        hailGrad.addColorStop(0.6, '#fda4af');
        hailGrad.addColorStop(1, '#e11d48');
      } else {
        hailGrad.addColorStop(0, '#ffffff');
        hailGrad.addColorStop(1, '#94a3b8');
      }

      ctx.beginPath();
      ctx.arc(curX, curY, visualRadius, 0, Math.PI * 2);
      ctx.fillStyle = hailGrad;
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Concentric rings inside the hailstone marker if large enough
      if (visualRadius >= 10) {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(curX, curY, visualRadius * 0.55, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Ground Impact Burst if at ground level
      if (currentPoint.altitudeKm <= 0 && currentStepIndex === trajectory.length - 1) {
        if (currentPoint.diameterMm > 0) {
          // Impact particles
          ctx.fillStyle = '#e0f2fe';
          for (let k = 0; k < 12; k++) {
            const angle = (k / 12) * Math.PI - Math.PI;
            const dist = 12 + (k % 4) * 6;
            const px = curX + Math.cos(angle) * dist;
            const py = curY + Math.sin(angle) * dist * 0.6;
            ctx.beginPath();
            ctx.arc(px, py, 2.5, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      // HUD Label above stone
      const labelY = curY - visualRadius - 14;
      const labelText = currentPoint.diameterMm > 0 
        ? `직경 ${currentPoint.diameterMm.toFixed(1)}mm (${currentPoint.massG.toFixed(1)}g)` 
        : '빗방울로 융해';
      
      ctx.font = 'bold 11px sans-serif';
      const textW = ctx.measureText(labelText).width;
      
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.roundRect(curX - textW / 2 - 6, labelY - 12, textW + 12, 18, 4);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText(labelText, curX, labelY + 1);

      ctx.restore();
    }

    // 8. Axis Labels & Elevation Scale (Left side)
    ctx.fillStyle = '#64748b';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'right';

    for (let alt = 0; alt <= Math.ceil(maxAlt); alt += 2) {
      const yPos = altToY(alt);
      ctx.fillText(`${alt}km`, leftMargin - 8, yPos + 3);

      // Tick mark
      ctx.strokeStyle = '#475569';
      ctx.beginPath();
      ctx.moveTo(leftMargin - 4, yPos);
      ctx.lineTo(leftMargin, yPos);
      ctx.stroke();
    }

    // Altitude Axis Title
    ctx.save();
    ctx.translate(14, topMargin + plotH / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = 'center';
    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('고도 (Altitude, km)', 0, 0);
    ctx.restore();

    // 9. Legend bar in canvas top right
    const legendX = leftMargin + plotW - 190;
    const legendY = topMargin + 8;
    ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
    ctx.roundRect(legendX, legendY, 182, 54, 6);
    ctx.fill();

    ctx.font = '10px sans-serif';
    ctx.textAlign = 'left';

    // Rime indicator
    ctx.fillStyle = '#fde047';
    ctx.fillRect(legendX + 8, legendY + 8, 10, 10);
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText('건성 성장 (불투명 백색층)', legendX + 24, legendY + 16);

    // Glaze indicator
    ctx.fillStyle = '#38bdf8';
    ctx.fillRect(legendX + 8, legendY + 22, 10, 10);
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText('습성 성장 (투명 얼음층)', legendX + 24, legendY + 30);

    // Melting indicator
    ctx.fillStyle = '#f43f5e';
    ctx.fillRect(legendX + 8, legendY + 36, 10, 10);
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText('0°C 이하 융해 (Melting)', legendX + 24, legendY + 44);

  }, [
    params,
    currentStepIndex,
    trajectory,
    currentPoint,
    showWindVectors,
    showTempLines,
    showTrajectoryTrail,
  ]);

  // Redraw on canvas resize or state changes
  useEffect(() => {
    renderCanvas();
  }, [renderCanvas]);

  // Resize canvas to match container width
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;
      
      const rect = container.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = 480;
      renderCanvas();
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [renderCanvas]);

  // Current mode descriptive badge
  const getModeBadge = (mode: string) => {
    switch (mode) {
      case 'dry_rime':
        return { text: '상승 중: 건성 백색 빙결 (Rime)', bg: 'bg-amber-500/20 text-amber-300 border-amber-500/30' };
      case 'wet_glaze':
        return { text: '순환 중: 습성 투명 빙결 (Glaze)', bg: 'bg-sky-500/20 text-sky-300 border-sky-500/30' };
      case 'melting':
        return { text: '하강 중: 0°C 이하 융해 (Melting)', bg: 'bg-rose-500/20 text-rose-300 border-rose-500/30' };
      default:
        return { text: '초기 빙결 배아 형성', bg: 'bg-slate-500/20 text-slate-300 border-slate-500/30' };
    }
  };

  const modeInfo = getModeBadge(currentPoint?.currentMode || 'embryo');

  return (
    <div className="flex flex-col bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Canvas Header & Status HUD */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 bg-slate-950/80 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-sm font-semibold text-slate-200">적란운 단면 대류 및 우박 궤적 시뮬레이션</span>
        </div>

        {/* Live Metrics HUD */}
        {currentPoint && (
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className={`px-2.5 py-1 rounded-full border font-medium ${modeInfo.bg}`}>
              {modeInfo.text}
            </span>
            <div className="flex flex-wrap items-center gap-3 px-3 py-1 bg-slate-800/80 rounded-lg text-slate-300 font-mono">
              <span>고도: <strong className="text-sky-400">{currentPoint.altitudeKm.toFixed(2)}km</strong></span>
              <span>기온: <strong className={currentPoint.tempC <= 0 ? 'text-blue-400' : 'text-rose-400'}>{currentPoint.tempC.toFixed(1)}°C</strong></span>
              <span>기압: <strong className="text-amber-300">{currentPoint.pressureHpa || Math.round(params.surfacePressure * Math.exp(-currentPoint.altitudeKm / 8.2))}hPa</strong></span>
              <span>직경: <strong className="text-emerald-400">{currentPoint.diameterMm.toFixed(1)}mm</strong></span>
              <span>순환: <strong className="text-purple-400">{currentPoint.cycleCount}회</strong></span>
            </div>
          </div>
        )}
      </div>

      {/* Main Interactive Canvas Area */}
      <div ref={containerRef} className="relative w-full bg-slate-950 min-h-[480px]">
        <canvas
          ref={canvasRef}
          className="w-full h-[480px] block cursor-crosshair"
        />

        {/* Overlaid Toggle Pills inside Canvas */}
        <div className="absolute top-3 left-16 flex flex-wrap gap-1.5 z-10">
          <button
            id="toggle-wind-vectors"
            onClick={() => setShowWindVectors(!showWindVectors)}
            className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1.5 transition-colors ${
              showWindVectors ? 'bg-orange-500/20 text-orange-300 border border-orange-500/40' : 'bg-slate-800/60 text-slate-400 border border-slate-700'
            }`}
          >
            <Wind className="w-3.5 h-3.5" />
            상승/하강 기류
          </button>

          <button
            id="toggle-temp-lines"
            onClick={() => setShowTempLines(!showTempLines)}
            className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1.5 transition-colors ${
              showTempLines ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40' : 'bg-slate-800/60 text-slate-400 border border-slate-700'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            0°C/-20°C 등온선
          </button>

          <button
            id="toggle-trajectory"
            onClick={() => setShowTrajectoryTrail(!showTrajectoryTrail)}
            className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1.5 transition-colors ${
              showTrajectoryTrail ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-800/60 text-slate-400 border border-slate-700'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            성장 궤적선
          </button>
        </div>
      </div>

      {/* Playback Controls & Timeline Scrubber */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-4 py-3 bg-slate-950 border-t border-slate-800">
        {/* Play/Pause & Reset */}
        <div className="flex items-center gap-2">
          <button
            id="sim-play-pause-btn"
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white rounded-lg text-xs font-medium transition-colors shadow-sm"
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-current" />
                일시정지
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                재생
              </>
            )}
          </button>

          <button
            id="sim-reset-btn"
            onClick={() => {
              setCurrentStepIndex(0);
              setIsPlaying(true);
              progressAccumRef.current = 0;
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium transition-colors border border-slate-700"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            처음부터
          </button>

          {/* Speed Selector */}
          <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-0.5 ml-2">
            {[0.5, 1, 2, 5].map((spd) => (
              <button
                key={spd}
                id={`speed-btn-${spd}`}
                onClick={() => setPlaybackSpeed(spd)}
                className={`px-2 py-1 text-xs rounded font-mono font-medium transition-colors ${
                  playbackSpeed === spd
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {spd}x
              </button>
            ))}
            <button
              id="instant-finish-btn"
              onClick={() => {
                setCurrentStepIndex(trajectory.length - 1);
                setIsPlaying(false);
              }}
              className="px-2 py-1 text-xs rounded text-slate-400 hover:text-slate-200 font-medium transition-colors flex items-center gap-1"
            >
              <FastForward className="w-3 h-3" />
              결과 즉시보기
            </button>
          </div>
        </div>

        {/* Timeline Slider */}
        <div className="flex items-center gap-3 w-full sm:w-72">
          <span className="text-xs text-slate-400 font-mono whitespace-nowrap">
            {currentPoint?.timeSec.toFixed(0)}s / {simResult.totalDurationSec}s
          </span>
          <input
            id="timeline-scrubber"
            type="range"
            min={0}
            max={Math.max(1, trajectory.length - 1)}
            value={currentStepIndex}
            onChange={(e) => {
              setCurrentStepIndex(Number(e.target.value));
              setIsPlaying(false);
            }}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
        </div>
      </div>
    </div>
  );
};
