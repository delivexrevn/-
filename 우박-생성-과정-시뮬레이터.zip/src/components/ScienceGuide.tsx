import React from 'react';
import { 
  BookOpen, 
  Sparkles, 
  ArrowUpCircle, 
  ArrowDownCircle, 
  Layers, 
  HelpCircle, 
  ThermometerSnowflake,
  SunMedium,
  CheckCircle2,
  Gauge,
  Droplets,
  Wind,
  Zap,
  Activity
} from 'lucide-react';

export const ScienceGuide: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: '강력한 대류 상승기류 & 빙정 배아 형성',
      desc: '지표면 가열과 상층 한기 유입으로 강력한 적란운(Cumulonimbus)이 발달합니다. 구름 하층에서 상승기류를 타고 올라간 물방울이 0°C 동결선 위에서 먼지나 빙결핵과 만나 직경 1~2mm의 작은 빙정 배아(Embryo)가 형성됩니다.',
      tag: '고도 2~4km / 동결선',
      color: 'border-sky-500/40 bg-sky-500/10 text-sky-300',
    },
    {
      num: '02',
      title: '과냉각 수분 포집 & 불투명 백색층(Rime) 형성',
      desc: '우박 배아가 시속 70~150km의 강력한 상승기류를 타고 영하 -20°C ~ -40°C의 극저온 상층부로 치솟습니다. 이때 영하에서도 얼지 않은 과냉각 물방울이 우박에 부딪히자마자 급격히 얼어붙으며 미세 공기방울이 갇혀 하얗고 불투명한 저밀도 건성 빙결층(Rime, ~0.78g/cm³)이 만들어집니다.',
      tag: '고도 6~12km / -20°C 이하',
      color: 'border-amber-500/40 bg-amber-500/10 text-amber-300',
    },
    {
      num: '03',
      title: '외곽 하강 & 투명 유리질층(Glaze) 형성',
      desc: '상승기류의 중심을 벗어나거나 무거워진 우박은 구름 가장자리의 하강기류를 타고 0°C ~ -15°C의 비교적 온화한 층으로 하강합니다. 수분이 풍부한 이곳에서는 물방울이 표면에 퍼진 뒤 서서히 얼면서 공기가 빠져나가 단단하고 투명한 고밀도 습성 빙결층(Glaze, ~0.91g/cm³)이 코팅됩니다.',
      tag: '고도 3~6km / -15°C~0°C',
      color: 'border-cyan-500/40 bg-cyan-500/10 text-cyan-300',
    },
    {
      num: '04',
      title: '다중 순환(Recirculation)과 양파 껍질 구조 완성',
      desc: '하강하던 우박이 하층의 윈드시어와 재유입 상승기류를 다시 만나면 위 과정을 수 차례(3~7회) 반복합니다. 이로 인해 우박을 반으로 쪼갰을 때 투명 층과 불투명 층이 번갈아 나타나는 동심원(양파 껍질) 구조가 완성됩니다.',
      tag: '다중 순환 루프',
      color: 'border-purple-500/40 bg-purple-500/10 text-purple-300',
    },
    {
      num: '05',
      title: '종단 속도 초과 및 지상 낙하 (융해 및 충돌)',
      desc: '우박의 무게가 상승기류가 떠받칠 수 있는 한계(종단 낙하 속도)를 초과하면 시속 60~160km의 엄청난 속도로 지상으로 낙하합니다. 0°C 동결선 아래를 통과하면서 표면이 일부 녹아내리며 최종 크기와 막대한 충격량(Impulse)으로 지상에 격돌합니다.',
      tag: '시속 60~160km 고속 낙하',
      color: 'border-rose-500/40 bg-rose-500/10 text-rose-300',
    },
  ];

  return (
    <div className="flex flex-col gap-6 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-400" />
            우박 생성의 과학적 원리 & 대기 역학 (Hailstorm Meteorology)
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            기상학적 메커니즘과 대기 물리 법칙(온도·습도·바람·대기압)으로 이해하는 우박의 탄생 원리입니다.
          </p>
        </div>
      </div>

      {/* 5-Step Process Cards */}
      <div className="flex flex-col gap-3">
        <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
          우박 성장 5단계 메커니즘
        </span>
        <div className="grid grid-cols-1 gap-3">
          {steps.map((step) => (
            <div
              key={step.num}
              className={`p-4 rounded-xl border flex flex-col sm:flex-row items-start gap-4 ${step.color}`}
            >
              <div className="w-9 h-9 rounded-lg bg-slate-950/80 border border-white/20 flex items-center justify-center font-mono font-black text-sm text-white shrink-0">
                {step.num}
              </div>
              <div className="flex flex-col flex-1 gap-1">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-white">{step.title}</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-950/60 font-mono text-slate-300 border border-white/10">
                    {step.tag}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed mt-0.5">
                  {step.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4 Deep Dive Q&A Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
        {/* Q1: Why summer/spring rather than winter? */}
        <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col gap-2">
          <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4" />
            왜 겨울이 아니라 5~6월(초여름)에 우박이 더 많이 올까요?
          </span>
          <p className="text-xs text-slate-300 leading-relaxed">
            우박이 만들어지려면 <strong>시속 100km 이상의 강력한 상승기류</strong>가 필요한데, 겨울철에는 지표면이 차가워 강한 상승기류(적란운)가 생기지 않습니다.
            반면 <strong>5~6월 초여름</strong>에는 강한 일사로 지면이 뜨거워져 대류가 활발한 동시에, 상층에는 여전히 -20°C 이하의 찬 공기가 남아있어 <strong>대기 불안정이 극대화</strong>되고 동결선 고도가 적절(2~3km)하여 우박이 녹지 않고 지상까지 쏟아집니다.
          </p>
        </div>

        {/* Q2: Rime vs Glaze layers */}
        <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col gap-2">
          <span className="text-xs font-bold text-sky-400 flex items-center gap-1.5">
            <Layers className="w-4 h-4" />
            우박 속 투명 층과 불투명 흰색 층의 비밀은?
          </span>
          <p className="text-xs text-slate-300 leading-relaxed">
            우박은 구름 속을 오르내리며 층을 형성합니다.
            <br />
            • <strong>불투명 백색층 (Rime)</strong>: 영하 -20°C 이하 상층에서 물방울이 닿자마자 순식간에 얼어붙어 수많은 미세 공기방울이 갇힌 저밀도(0.78g/cm³) 층입니다.
            <br />
            • <strong>투명한 얼음층 (Glaze)</strong>: 영하 0°C~-10°C 하층에서 물방울이 천천히 얼며 공기가 빠져나가 단단하고 투명한 고밀도(0.91g/cm³) 얼음이 됩니다.
          </p>
        </div>

        {/* Q3: Wind Shear & Pressure impact */}
        <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col gap-2">
          <span className="text-xs font-bold text-purple-400 flex items-center gap-1.5">
            <Wind className="w-4 h-4" />
            바람(윈드시어)과 대기압은 우박에 어떤 영향을 주나요?
          </span>
          <p className="text-xs text-slate-300 leading-relaxed">
            • <strong>윈드시어(수평 풍속 변화)</strong>: 상승기류를 옆으로 기울여 우박이 강수 하강기류와 분리되게 함으로써, 우박이 구름 내부에 오랫동안 머물며 수 차례 재순환하여 거대화되도록 돕습니다.
            <br />
            • <strong>대기압과 공기 밀도</strong>: 기압이 낮으면 상공의 공기 밀도가 감소하여 공기 저항이 줄어들고, 지상 낙하 종단 속도와 최종 충격력이 크게 증가합니다.
          </p>
        </div>

        {/* Q4: Watermelon impulse physics */}
        <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col gap-2">
          <span className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
            <Activity className="w-4 h-4" />
            우박의 충격량(Impulse)과 수박 파괴 기준은?
          </span>
          <p className="text-xs text-slate-300 leading-relaxed">
            • <strong>충격량 $J = m \cdot v$</strong>: 우박의 질량과 지상 종단속도의 곱으로, 물체에 전달되는 총 운동량의 변화를 뜻합니다.
            <br />
            • <strong>수박 파괴 지표</strong>: 농업 및 생체역학 실험상 성인 통수박(약 7kg) 1개를 완전히 박살내는 데 필요한 에너지는 약 <strong>14 Joules (충격량 약 0.85 N·s)</strong>입니다. 직경 45mm 이상의 골프공급 우박부터 수박을 일격에 두동강 낼 수 있습니다.
          </p>
        </div>
      </div>
    </div>
  );
};
