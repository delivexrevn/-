import React, { useState, useEffect, useRef, useCallback } from 'react';
import { HailSimulationResult } from '../types';
import { 
  Play, 
  RotateCcw, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Flame,
  Zap,
  Info,
  Layers,
  ArrowDown,
  Activity,
  ShieldCheck,
  TrendingDown
} from 'lucide-react';

interface WatermelonSmashProps {
  simResult: HailSimulationResult;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  rotation: number;
  vRot: number;
}

export const WatermelonSmash: React.FC<WatermelonSmashProps> = ({ simResult }) => {
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [hasCompleted, setHasCompleted] = useState<boolean>(false);
  const [currentSmashedCount, setCurrentSmashedCount] = useState<number>(0);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const particlesRef = useRef<Particle[]>([]);

  const { 
    finalDiameterMm, 
    terminalVelocityKmh, 
    impactEnergyJoules, 
    impactImpulseNs, 
    impactPeakForceKn, 
    watermelonImpact 
  } = simResult;
  const isMelted = finalDiameterMm <= 0;

  // Web Audio synthetic smash & crack sounds
  const playSmashSound = useCallback((intensity: number) => {
    if (!soundEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      // Heavy impact thud with sharp initial transient
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(160 + intensity * 20, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(25, ctx.currentTime + 0.22);
      
      const vol = Math.min(0.85, 0.2 + intensity * 0.12);
      gain.gain.setValueAtTime(vol, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + 0.28);
    } catch {
      // Audio context might be restricted before user gesture
    }
  }, [soundEnabled]);

  // Main simulation animation engine
  const startSmashSimulation = useCallback(() => {
    setIsSimulating(true);
    setHasCompleted(false);
    setCurrentSmashedCount(0);
    particlesRef.current = [];

    const totalToBreak = watermelonImpact.watermelonsBroken;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const startTime = performance.now();
    let lastBrokenFloor = 0;
    let hasImpactedFirst = false;

    // Canvas geometry constants
    const centerX = canvas.width / 2; // 400
    const groundY = 370;
    const melonHeight = 36; // spacing between stacked watermelons
    const visualStackCount = Math.min(8, Math.max(4, Math.ceil(totalToBreak) + 1));
    
    // Stack position from top to bottom
    // Top melon index = 0, Bottom melon index = visualStackCount - 1
    const getMelonY = (stackIndexFromTop: number) => {
      // Stack base sits on groundY
      const baseIndexFromBottom = visualStackCount - 1 - stackIndexFromTop;
      return groundY - 22 - (baseIndexFromBottom * melonHeight);
    };

    const topMelonY = getMelonY(0);

    const spawnParticles = (x: number, y: number, count: number, force: number) => {
      const colors = ['#ef4444', '#dc2626', '#b91c1c', '#991b1b', '#15803d', '#166534', '#18181b', '#fca5a5', '#e0f2fe'];
      for (let i = 0; i < count; i++) {
        // Explode outward mainly horizontally and slightly upward
        const angle = (Math.random() > 0.5 ? 0 : Math.PI) + (Math.random() - 0.5) * 1.4;
        const speed = (3 + Math.random() * 9) * force;
        particlesRef.current.push({
          x: x + (Math.random() - 0.5) * 20,
          y: y + (Math.random() - 0.5) * 12,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - Math.random() * 5,
          size: 2.5 + Math.random() * 6,
          color: colors[Math.floor(Math.random() * colors.length)],
          alpha: 1,
          rotation: Math.random() * Math.PI * 2,
          vRot: (Math.random() - 0.5) * 0.3,
        });
      }
    };

    const render = (time: number) => {
      const elapsed = ((time - startTime) / 1000) * playbackSpeed;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // 1. Draw Storm Sky at Top
      const skyGrad = ctx.createLinearGradient(0, 0, 0, 90);
      skyGrad.addColorStop(0, '#090d16');
      skyGrad.addColorStop(0.7, '#0f172a');
      skyGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, canvas.width, 90);

      // Sky storm clouds
      ctx.fillStyle = 'rgba(30, 41, 59, 0.7)';
      ctx.beginPath();
      ctx.arc(centerX - 80, 20, 50, 0, Math.PI * 2);
      ctx.arc(centerX, 15, 65, 0, Math.PI * 2);
      ctx.arc(centerX + 80, 25, 55, 0, Math.PI * 2);
      ctx.fill();

      // Sky Label
      ctx.fillStyle = '#64748b';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('▲ 상공 1,000m 적란운 (수직 낙하 개시선)', centerX, 24);

      // 2. Draw Ground Base Table / Reinforced Platform
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, groundY, canvas.width, canvas.height - groundY);
      
      // Steel platform with shock absorber patterns
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(centerX - 140, groundY, 280, 14);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(centerX - 140, groundY);
      ctx.lineTo(centerX + 140, groundY);
      ctx.stroke();

      // Platform label
      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('▼ 지상 수박 수직 적층 시험대 (Ground Base Platform)', centerX, groundY + 28);

      // 3. Left Altitude / Energy Scale Ruler
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 3]);
      ctx.beginPath();
      ctx.moveTo(110, 60);
      ctx.lineTo(110, groundY);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = '#64748b';
      ctx.font = '9px monospace';
      ctx.textAlign = 'right';
      ctx.fillText('하늘 (Sky)', 100, 70);
      ctx.fillText('수직 적층탑', 100, (topMelonY + groundY) / 2);
      ctx.fillText('지표면 (0m)', 100, groundY);

      // 4. Calculate Current Hail Position and Penetration
      const dropDuration = 0.45; // seconds to fall from sky to top watermelon
      let currentHailY = -30;
      let isDropping = elapsed < dropDuration;

      if (isDropping) {
        // Fall from sky (-30) to top watermelon (topMelonY)
        const dropT = Math.min(1, elapsed / dropDuration);
        currentHailY = -30 + Math.pow(dropT, 2.2) * (topMelonY + 30);
      } else {
        if (!hasImpactedFirst) {
          hasImpactedFirst = true;
          playSmashSound(Math.min(5, totalToBreak));
          spawnParticles(centerX, topMelonY, Math.min(60, 20 + Math.floor(totalToBreak * 8)), 2.2);
        }

        // Penetration phase downwards through the Y stack
        const smashDuration = 1.3;
        const smashProgress = Math.min(1, (elapsed - dropDuration) / smashDuration);
        const currentBroken = totalToBreak * Math.pow(smashProgress, 0.75);
        setCurrentSmashedCount(currentBroken);

        // Calculate penetration depth in Y
        const brokenFloored = Math.floor(currentBroken);
        if (brokenFloored > lastBrokenFloor) {
          lastBrokenFloor = brokenFloored;
          const currentMelonY = getMelonY(Math.min(visualStackCount - 1, brokenFloored - 1));
          playSmashSound(Math.max(1, totalToBreak - brokenFloored + 1));
          spawnParticles(centerX, currentMelonY, 30, 1.8);
        }

        // Hail moves down with penetration
        const maxPenetrationMelonIndex = Math.min(visualStackCount - 1, currentBroken);
        currentHailY = topMelonY + (maxPenetrationMelonIndex * melonHeight);

        if (smashProgress >= 1 && !hasCompleted) {
          setHasCompleted(true);
          setIsSimulating(false);
        }
      }

      // 5. Draw Vertically Stacked Watermelons (from bottom to top)
      for (let stackIdx = visualStackCount - 1; stackIdx >= 0; stackIdx--) {
        const my = getMelonY(stackIdx);
        const isShattered = !isDropping && (stackIdx < Math.floor(currentSmashedCount));
        const isPartialCracked = !isDropping && (stackIdx === Math.floor(currentSmashedCount) && (currentSmashedCount % 1) > 0.1);
        const partialRatio = currentSmashedCount % 1;

        ctx.save();
        ctx.translate(centerX, my);

        if (isShattered) {
          // Pulverized / Split watermelon halves blown outward
          const splitDist = 18 + Math.min(16, (visualStackCount - stackIdx) * 2);
          
          // Crushed red pulp in middle
          ctx.fillStyle = '#b91c1c';
          ctx.beginPath();
          ctx.ellipse(0, 8, 22, 10, 0, 0, Math.PI * 2);
          ctx.fill();

          // Left Half
          ctx.save();
          ctx.translate(-splitDist, 4);
          ctx.rotate(-0.35);
          ctx.fillStyle = '#dc2626'; // Red flesh
          ctx.beginPath();
          ctx.arc(0, 0, 16, 0, Math.PI, false);
          ctx.fill();
          ctx.strokeStyle = '#15803d'; // Green rind
          ctx.lineWidth = 3.5;
          ctx.stroke();
          // Seeds
          ctx.fillStyle = '#0f172a';
          ctx.beginPath();
          ctx.arc(-4, 4, 1.5, 0, Math.PI * 2);
          ctx.arc(4, 6, 1.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

          // Right Half
          ctx.save();
          ctx.translate(splitDist, 4);
          ctx.rotate(0.35);
          ctx.fillStyle = '#dc2626';
          ctx.beginPath();
          ctx.arc(0, 0, 16, 0, Math.PI, false);
          ctx.fill();
          ctx.strokeStyle = '#15803d';
          ctx.lineWidth = 3.5;
          ctx.stroke();
          // Seeds
          ctx.fillStyle = '#0f172a';
          ctx.beginPath();
          ctx.arc(-3, 6, 1.5, 0, Math.PI * 2);
          ctx.arc(5, 4, 1.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

        } else if (isPartialCracked) {
          // Heavy stress crack with red interior glowing
          ctx.fillStyle = '#16a34a';
          ctx.beginPath();
          ctx.ellipse(0, 0, 26, 18, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#14532d';
          ctx.lineWidth = 3;
          ctx.stroke();

          // Dark green stripes
          ctx.strokeStyle = '#052e16';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.moveTo(-18, -12);
          ctx.quadraticCurveTo(-22, 0, -18, 12);
          ctx.moveTo(0, -18);
          ctx.quadraticCurveTo(-3, 0, 0, 18);
          ctx.moveTo(18, -12);
          ctx.quadraticCurveTo(22, 0, 18, 12);
          ctx.stroke();

          // Jagged red impact cracks
          ctx.strokeStyle = '#dc2626';
          ctx.lineWidth = 2 + partialRatio * 2.5;
          ctx.beginPath();
          ctx.moveTo(-4, -18);
          ctx.lineTo(2, -6);
          ctx.lineTo(-3, 4);
          ctx.lineTo(5, 16);
          ctx.stroke();

          ctx.beginPath();
          ctx.moveTo(3, -8);
          ctx.lineTo(12, 0);
          ctx.stroke();

        } else {
          // Intact Glossy Watermelon in Vertical Stack
          ctx.fillStyle = '#22c55e';
          ctx.beginPath();
          ctx.ellipse(0, 0, 26, 18, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#15803d';
          ctx.lineWidth = 3;
          ctx.stroke();

          // Dark Green Vertical Stripes
          ctx.strokeStyle = '#14532d';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.moveTo(-18, -12);
          ctx.quadraticCurveTo(-22, 0, -18, 12);
          ctx.moveTo(-6, -17);
          ctx.quadraticCurveTo(-9, 0, -6, 17);
          ctx.moveTo(6, -17);
          ctx.quadraticCurveTo(3, 0, 6, 17);
          ctx.moveTo(18, -12);
          ctx.quadraticCurveTo(22, 0, 18, 12);
          ctx.stroke();

          // Glossy highlight reflection
          ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
          ctx.beginPath();
          ctx.ellipse(-8, -6, 10, 4, -0.2, 0, Math.PI * 2);
          ctx.fill();

          // Stem at top if topmost intact melon
          if (stackIdx === 0) {
            ctx.strokeStyle = '#854d0e';
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.moveTo(0, -18);
            ctx.lineTo(4, -24);
            ctx.stroke();
          }
        }

        // Layer Tier Label on the right
        ctx.fillStyle = isShattered ? '#f87171' : isPartialCracked ? '#fbbf24' : '#94a3b8';
        ctx.font = '10px monospace';
        ctx.textAlign = 'left';
        const labelText = `Y-Layer #${stackIdx + 1} (${stackIdx === 0 ? '최상단 직격점' : `${stackIdx + 1}층`})`;
        ctx.fillText(labelText, 36, 4);

        if (isShattered) {
          ctx.fillStyle = '#ef4444';
          ctx.fillText('💥 완파 (Smashed)', 170, 4);
        } else if (isPartialCracked) {
          ctx.fillStyle = '#f59e0b';
          ctx.fillText('⚡ 균열 파손 (Cracked)', 170, 4);
        } else {
          ctx.fillStyle = '#10b981';
          ctx.fillText('🛡️ 원형 유지 (Intact)', 170, 4);
        }

        ctx.restore();
      }

      // 6. Draw Falling / Penetrating Hailstone
      const hailDrawRadius = Math.min(32, Math.max(8, (finalDiameterMm / 2) * 0.7));
      ctx.save();
      ctx.translate(centerX, currentHailY);

      // Vapor speed streak behind hail if falling fast
      if (isDropping) {
        ctx.strokeStyle = 'rgba(186, 230, 253, 0.4)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(0, -60);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-6, 0);
        ctx.lineTo(-6, -45);
        ctx.moveTo(6, 0);
        ctx.lineTo(6, -45);
        ctx.stroke();
      }

      // Hail glowing frost halo
      const grad = ctx.createRadialGradient(0, 0, 2, 0, 0, hailDrawRadius * 1.7);
      grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
      grad.addColorStop(0.5, 'rgba(186, 230, 253, 0.9)');
      grad.addColorStop(1, 'rgba(56, 189, 248, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(0, 0, hailDrawRadius * 1.7, 0, Math.PI * 2);
      ctx.fill();

      // Hail solid sphere
      ctx.fillStyle = '#e0f2fe';
      ctx.beginPath();
      ctx.arc(0, 0, hailDrawRadius, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Internal crystalline ice lines
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(-hailDrawRadius * 0.5, -hailDrawRadius * 0.3);
      ctx.lineTo(hailDrawRadius * 0.3, hailDrawRadius * 0.4);
      ctx.moveTo(-hailDrawRadius * 0.2, hailDrawRadius * 0.5);
      ctx.lineTo(hailDrawRadius * 0.5, -hailDrawRadius * 0.2);
      ctx.stroke();

      ctx.restore();

      // 7. Update & Draw Particles (Watermelon Juice, Flesh, Rind & Seeds)
      for (let pIdx = particlesRef.current.length - 1; pIdx >= 0; pIdx--) {
        const p = particlesRef.current[pIdx];
        p.x += p.vx * playbackSpeed;
        p.y += p.vy * playbackSpeed;
        p.vy += 0.3 * playbackSpeed; // Gravity
        p.alpha -= 0.018 * playbackSpeed;
        p.rotation += p.vRot;

        if (p.alpha <= 0 || p.y > groundY + 30) {
          particlesRef.current.splice(pIdx, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      }

      if (isSimulating || !hasCompleted) {
        animFrameRef.current = requestAnimationFrame(render);
      }
    };

    animFrameRef.current = requestAnimationFrame(render);
  }, [finalDiameterMm, hasCompleted, isSimulating, playbackSpeed, playSmashSound, watermelonImpact.watermelonsBroken]);

  // Initial draw once canvas mounts or params change (Static Vertical Preview)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const centerX = canvas.width / 2; // 400
    const groundY = 370;
    const melonHeight = 36;
    const visualStackCount = Math.min(8, Math.max(4, Math.ceil(watermelonImpact.watermelonsBroken) + 1));

    const getMelonY = (stackIndexFromTop: number) => {
      const baseIndexFromBottom = visualStackCount - 1 - stackIndexFromTop;
      return groundY - 22 - (baseIndexFromBottom * melonHeight);
    };

    // 1. Draw Storm Sky at Top
    const skyGrad = ctx.createLinearGradient(0, 0, 0, 90);
    skyGrad.addColorStop(0, '#090d16');
    skyGrad.addColorStop(0.7, '#0f172a');
    skyGrad.addColorStop(1, 'transparent');
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, canvas.width, 90);

    // Sky clouds
    ctx.fillStyle = 'rgba(30, 41, 59, 0.7)';
    ctx.beginPath();
    ctx.arc(centerX - 80, 20, 50, 0, Math.PI * 2);
    ctx.arc(centerX, 15, 65, 0, Math.PI * 2);
    ctx.arc(centerX + 80, 25, 55, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#64748b';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('▲ 상공 1,000m 적란운 (수직 낙하 대기)', centerX, 24);

    // 2. Draw Ground Base Platform
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, groundY, canvas.width, canvas.height - groundY);
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(centerX - 140, groundY, 280, 14);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(centerX - 140, groundY);
    ctx.lineTo(centerX + 140, groundY);
    ctx.stroke();

    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('▼ 지상 수박 수직 적층 시험대 (Ground Base Platform)', centerX, groundY + 28);

    // 3. Draw Intact Vertical Stack
    for (let stackIdx = visualStackCount - 1; stackIdx >= 0; stackIdx--) {
      const my = getMelonY(stackIdx);

      ctx.save();
      ctx.translate(centerX, my);

      ctx.fillStyle = '#22c55e';
      ctx.beginPath();
      ctx.ellipse(0, 0, 26, 18, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 3;
      ctx.stroke();

      // Dark Green Vertical Stripes
      ctx.strokeStyle = '#14532d';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(-18, -12);
      ctx.quadraticCurveTo(-22, 0, -18, 12);
      ctx.moveTo(-6, -17);
      ctx.quadraticCurveTo(-9, 0, -6, 17);
      ctx.moveTo(6, -17);
      ctx.quadraticCurveTo(3, 0, 6, 17);
      ctx.moveTo(18, -12);
      ctx.quadraticCurveTo(22, 0, 18, 12);
      ctx.stroke();

      // Glossy highlight
      ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.beginPath();
      ctx.ellipse(-8, -6, 10, 4, -0.2, 0, Math.PI * 2);
      ctx.fill();

      if (stackIdx === 0) {
        ctx.strokeStyle = '#854d0e';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(0, -18);
        ctx.lineTo(4, -24);
        ctx.stroke();
      }

      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`Y-Layer #${stackIdx + 1} (${stackIdx === 0 ? '최상단 직격점' : `${stackIdx + 1}층`})`, 36, 4);

      ctx.restore();
    }

    // 4. Hovering Ready Hailstone high up in the sky
    const hailDrawRadius = Math.min(32, Math.max(8, (finalDiameterMm / 2) * 0.7));
    ctx.save();
    ctx.translate(centerX, 50);

    const grad = ctx.createRadialGradient(0, 0, 2, 0, 0, hailDrawRadius * 1.7);
    grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
    grad.addColorStop(0.5, 'rgba(186, 230, 253, 0.9)');
    grad.addColorStop(1, 'rgba(56, 189, 248, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(0, 0, hailDrawRadius * 1.7, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#e0f2fe';
    ctx.beginPath();
    ctx.arc(0, 0, hailDrawRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#0284c7';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Direction arrow pointing straight down to stack
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, hailDrawRadius + 6);
    ctx.lineTo(0, hailDrawRadius + 22);
    ctx.stroke();

    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.moveTo(0, hailDrawRadius + 28);
    ctx.lineTo(-5, hailDrawRadius + 20);
    ctx.lineTo(5, hailDrawRadius + 20);
    ctx.fill();

    ctx.restore();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [finalDiameterMm, watermelonImpact.watermelonsBroken]);

  return (
    <div className="flex flex-col gap-5 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl text-slate-200">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl">🍉</span>
            <h2 className="text-base font-bold text-white">
              우박 수직 낙하 & Y축 수박 적층탑 파괴 시뮬레이션
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            우박이 하늘 높은 곳에서 수직 낙하하여 Y축으로 쌓아 올린 수박 타워를 상단부터 차례대로 몇 층까지 관통 파쇄하는지 역학 시뮬레이션합니다.
          </p>
        </div>

        {/* Status Badge */}
        <div className="flex items-center gap-2">
          <span
            className={`text-xs px-3 py-1 rounded-full font-bold border flex items-center gap-1.5 ${
              watermelonImpact.destructiveTier === 'annihilate'
                ? 'bg-rose-600/20 text-rose-300 border-rose-500 shadow-sm shadow-rose-500/20'
                : watermelonImpact.destructiveTier === 'shatter'
                ? 'bg-orange-600/20 text-orange-300 border-orange-500'
                : watermelonImpact.destructiveTier === 'crack'
                ? 'bg-amber-600/20 text-amber-300 border-amber-500'
                : 'bg-emerald-600/20 text-emerald-300 border-emerald-500'
            }`}
          >
            {watermelonImpact.destructiveTier === 'annihilate' ? (
              <Flame className="w-3.5 h-3.5 text-rose-400" />
            ) : (
              <Zap className="w-3.5 h-3.5" />
            )}
            {watermelonImpact.statusTitleKo}
          </span>
        </div>
      </div>

      {/* Physics KPI Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Metric 1: Watermelons Broken */}
        <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-rose-400" />
            수박 타워 관통 파괴 개수
          </span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-2xl sm:text-3xl font-black text-rose-400 font-mono">
              {watermelonImpact.watermelonsBroken}
            </span>
            <span className="text-xs text-slate-400 font-bold">개 층 완파</span>
          </div>
          <span className="text-[10px] text-slate-400">
            상단부터 {watermelonImpact.exactCount}개 층 완전 분쇄
          </span>
        </div>

        {/* Metric 2: Impact Impulse */}
        <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            수직 충격량 (Impulse, J = Δp)
          </span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-2xl sm:text-3xl font-black text-amber-400 font-mono">
              {impactImpulseNs}
            </span>
            <span className="text-xs text-slate-400 font-mono">N·s</span>
          </div>
          <span className="text-[10px] text-slate-400">
            질량 × 수직 종단낙하속도
          </span>
        </div>

        {/* Metric 3: Kinetic Energy */}
        <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
            <Activity className="w-3.5 h-3.5 text-sky-400" />
            충격 운동 에너지 (Energy)
          </span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-2xl sm:text-3xl font-black text-sky-400 font-mono">
              {impactEnergyJoules}
            </span>
            <span className="text-xs text-slate-400 font-mono">Joules (J)</span>
          </div>
          <span className="text-[10px] text-slate-400">
            수박 1개 완파 기준 ~14 J
          </span>
        </div>

        {/* Metric 4: Peak Force */}
        <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
            <TrendingDown className="w-3.5 h-3.5 text-purple-400" />
            최대 충격 첨두력 (Peak Force)
          </span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-2xl sm:text-3xl font-black text-purple-400 font-mono">
              {impactPeakForceKn}
            </span>
            <span className="text-xs text-slate-400 font-mono">kN</span>
          </div>
          <span className="text-[10px] text-slate-400">
            충돌 시간 2ms 순간 하중
          </span>
        </div>
      </div>

      {/* Interactive Smash Stage Canvas */}
      <div className="flex flex-col gap-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            수직 적층 수박 타워 충격 시험대 (Vertical Y-Stack Testbed)
          </span>

          <div className="flex items-center gap-2">
            {/* Speed selection */}
            <div className="flex items-center bg-slate-950 rounded-lg p-0.5 border border-slate-800 text-[11px]">
              <button
                onClick={() => setPlaybackSpeed(0.5)}
                className={`px-2 py-0.5 rounded ${playbackSpeed === 0.5 ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
              >
                0.5x 슬로우
              </button>
              <button
                onClick={() => setPlaybackSpeed(1)}
                className={`px-2 py-0.5 rounded ${playbackSpeed === 1 ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
              >
                1x 정상
              </button>
              <button
                onClick={() => setPlaybackSpeed(2)}
                className={`px-2 py-0.5 rounded ${playbackSpeed === 2 ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
              >
                2x 배속
              </button>
            </div>

            {/* Sound toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              title="사운드 온/오프"
              className={`p-1.5 rounded-lg border text-xs transition-colors ${
                soundEnabled
                  ? 'bg-slate-800 border-slate-700 text-amber-400'
                  : 'bg-slate-950 border-slate-800 text-slate-500'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>

            {/* Simulation Trigger Button */}
            <button
              id="start-watermelon-smash-btn"
              onClick={startSmashSimulation}
              disabled={isSimulating || isMelted}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-md ${
                isMelted
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : isSimulating
                  ? 'bg-amber-600 text-white cursor-wait animate-pulse'
                  : 'bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 hover:from-red-500 hover:to-amber-500 active:scale-95 text-white'
              }`}
            >
              {isSimulating ? (
                <>
                  <Play className="w-3.5 h-3.5 animate-spin" />
                  우박 수직 강하 중...
                </>
              ) : hasCompleted ? (
                <>
                  <RotateCcw className="w-3.5 h-3.5" />
                  수직 투하 다시하기
                </>
              ) : (
                <>
                  <ArrowDown className="w-3.5 h-3.5 animate-bounce" />
                  하늘 위에서 우박 투하하기!
                </>
              )}
            </button>
          </div>
        </div>

        {/* Canvas Box */}
        <div className="relative w-full h-[420px] bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-inner flex items-center justify-center">
          <canvas
            ref={canvasRef}
            width={800}
            height={420}
            className="w-full h-full object-contain"
          />

          {/* Watermark/Overlay info */}
          <div className="absolute top-2.5 left-3 text-[11px] text-slate-400 flex items-center gap-2 bg-slate-900/80 backdrop-blur-sm px-2.5 py-1 rounded-md border border-slate-800">
            <span>우박 직경: <strong className="text-white font-mono">{finalDiameterMm}mm</strong></span>
            <span className="text-slate-600">|</span>
            <span>수직 종단속도: <strong className="text-sky-300 font-mono">{terminalVelocityKmh} km/h</strong></span>
          </div>

          {/* Smashed count banner overlay */}
          {hasCompleted && (
            <div className="absolute bottom-3 right-3 bg-rose-950/90 border border-rose-500/50 text-rose-200 px-3.5 py-1.5 rounded-lg text-xs font-bold shadow-lg animate-bounce">
              💥 Y축 수박 타워 {watermelonImpact.watermelonsBroken}개 층 수직 관통 완료!
            </div>
          )}
        </div>
      </div>

      {/* Physics Explanation Card */}
      <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col gap-2">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
          <Info className="w-4 h-4 text-blue-400" />
          수직 적층 수박 타워 관통 역학 (Vertical Stack Impact Dynamics)
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          {watermelonImpact.damageDescriptionKo}
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-1 pt-2 border-t border-slate-800/80 text-[11px] text-slate-400">
          <div>
            • <strong>수직 충격량 공식 (Impulse):</strong> J = m · v = Δp (우박 질량과 지상 수직 종단속도의 곱)
          </div>
          <div>
            • <strong>파쇄 기준 (Smash Threshold):</strong> 7kg 표준 수박 1개 완파 에너지 ≈ 14 Joules (충격량 약 0.85 N·s)
          </div>
        </div>
      </div>
    </div>
  );
};
