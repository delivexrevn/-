import React from 'react';
import { HailParameters, PresetScenario } from '../types';
import { PRESET_SCENARIOS } from '../data/presets';
import { 
  Wind, 
  Droplets, 
  ThermometerSnowflake, 
  CloudSun, 
  CloudFog, 
  RotateCcw, 
  Sparkles, 
  HelpCircle,
  Zap,
  Gauge,
  Layers,
  Activity,
  Compass
} from 'lucide-react';

interface ParameterPanelProps {
  params: HailParameters;
  onChangeParams: (newParams: HailParameters) => void;
  onApplyPreset: (preset: PresetScenario) => void;
  activePresetId: string | null;
}

export const ParameterPanel: React.FC<ParameterPanelProps> = ({
  params,
  onChangeParams,
  onApplyPreset,
  activePresetId,
}) => {
  const updateParam = <K extends keyof HailParameters>(key: K, value: HailParameters[K]) => {
    onChangeParams({
      ...params,
      [key]: value,
    });
  };

  // Updraft support rating estimation
  const getUpdraftRating = (v: number) => {
    if (v < 20) return { label: '약함 (싸락눈/비 융해)', color: 'text-slate-400' };
    if (v < 35) return { label: '보통 (동전 크기 지탱)', color: 'text-sky-400' };
    if (v < 48) return { label: '강함 (골프공 크기 지탱)', color: 'text-amber-400' };
    return { label: '초강력 (야구공 이상 거대 우박 지탱)', color: 'text-rose-400' };
  };

  // Melting risk estimation
  const getMeltingRisk = (surfTemp: number, freezeLvl: number, humidity: number) => {
    const score = (surfTemp - 20) * 0.35 + freezeLvl * 0.5 + (humidity / 100) * 1.5;
    if (score > 4.8) return { label: '매우 높음 (지상 도달 전 비로 녹을 가능성)', color: 'text-rose-400' };
    if (score > 3.2) return { label: '중간 (직경 15~30% 감소)', color: 'text-amber-400' };
    return { label: '낮음 (거의 녹지 않고 원형 유지)', color: 'text-emerald-400' };
  };

  // Estimated surface air density
  const estimatedAirDensity = (params.surfacePressure * 100) / (287.05 * (params.surfaceTemp + 273.15));

  const updraftRating = getUpdraftRating(params.updraftVelocity);
  const meltingRisk = getMeltingRisk(params.surfaceTemp, params.freezingLevel, params.relativeHumidity);

  return (
    <div className="flex flex-col gap-6 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl text-slate-200">
      {/* Panel Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            대기 기상 변수 제어 패널 (Meteorological Parameter Controls)
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            온도, 습도, 바람(상승기류/윈드시어), 대기압을 조절하여 우박의 크기, 밀도, 성장 속도를 실시간 변경하세요.
          </p>
        </div>
      </div>

      {/* Preset Scenarios Selector */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-blue-400" />
          기상 시나리오 프리셋
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
          {PRESET_SCENARIOS.map((preset) => {
            const isSelected = activePresetId === preset.id;
            return (
              <button
                key={preset.id}
                id={`preset-btn-${preset.id}`}
                onClick={() => onApplyPreset(preset)}
                className={`p-3 rounded-lg text-left transition-all border ${
                  isSelected
                    ? 'bg-blue-600/20 border-blue-500 shadow-sm ring-1 ring-blue-500/50'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-white truncate mr-1">
                    {preset.nameKo}
                  </span>
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded font-semibold shrink-0 ${
                      preset.badgeKo === '재난급'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : preset.badgeKo === '경보급'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                    }`}
                  >
                    {preset.badgeKo}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 line-clamp-2 leading-relaxed">
                  {preset.descriptionKo}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Meteorological Parameters Grid (4 Categories) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* 1. TEMPERATURE CONTROLS */}
        <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col gap-3.5">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <ThermometerSnowflake className="w-4 h-4 text-sky-400" />
              1. 온도 (Temperature)
            </span>
            <span className="text-[10px] text-sky-300 bg-sky-950/80 px-1.5 py-0.5 rounded border border-sky-800">
              열역학
            </span>
          </div>

          {/* Surface Temp */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">지상 기온 (Surface Temp)</span>
              <span className="font-mono font-bold text-amber-300">{params.surfaceTemp}°C</span>
            </div>
            <input
              type="range"
              min="10"
              max="40"
              step="1"
              value={params.surfaceTemp}
              onChange={(e) => updateParam('surfaceTemp', parseFloat(e.target.value))}
              className="w-full accent-amber-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">
              * 기온이 높을수록 하층 융해 위험 증가
            </span>
          </div>

          {/* Cloud Top Temp */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">운정 기온 (Cloud Top Temp)</span>
              <span className="font-mono font-bold text-sky-300">{params.cloudTopTemp}°C</span>
            </div>
            <input
              type="range"
              min="-65"
              max="-20"
              step="1"
              value={params.cloudTopTemp}
              onChange={(e) => updateParam('cloudTopTemp', parseFloat(e.target.value))}
              className="w-full accent-sky-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">
              * -40°C 이하 시 강력한 건성 급속 동결
            </span>
          </div>

          {/* Freezing Level */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">0°C 빙결 고도 (Freezing Level)</span>
              <span className="font-mono font-bold text-blue-300">{params.freezingLevel.toFixed(1)} km</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="5.0"
              step="0.1"
              value={params.freezingLevel}
              onChange={(e) => updateParam('freezingLevel', parseFloat(e.target.value))}
              className="w-full accent-blue-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">
              * 빙결선 이하 영역에서 우박 융해 발생
            </span>
          </div>

          {/* Cloud Top Altitude */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">구름 상한 고도 (Cloud Top)</span>
              <span className="font-mono font-bold text-indigo-300">{params.cloudTopAltitude.toFixed(1)} km</span>
            </div>
            <input
              type="range"
              min="7.0"
              max="18.0"
              step="0.5"
              value={params.cloudTopAltitude}
              onChange={(e) => updateParam('cloudTopAltitude', parseFloat(e.target.value))}
              className="w-full accent-indigo-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
          </div>
        </div>

        {/* 2. HUMIDITY & WATER CONTROLS */}
        <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col gap-3.5">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <Droplets className="w-4 h-4 text-emerald-400" />
              2. 습도 & 수분량 (Humidity)
            </span>
            <span className="text-[10px] text-emerald-300 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-800">
              응결·밀도
            </span>
          </div>

          {/* Relative Humidity */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">대기 상대습도 (Relative Humidity)</span>
              <span className="font-mono font-bold text-emerald-300">{params.relativeHumidity}%</span>
            </div>
            <input
              type="range"
              min="30"
              max="100"
              step="5"
              value={params.relativeHumidity}
              onChange={(e) => updateParam('relativeHumidity', parseInt(e.target.value, 10))}
              className="w-full accent-emerald-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">
              * 고습도일수록 과냉각 수적 보존 및 고밀도 얼음 생성
            </span>
          </div>

          {/* Supercooled Liquid Water (SLW) */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">과냉각 수적량 (SLW)</span>
              <span className="font-mono font-bold text-teal-300">{params.supercooledWater.toFixed(1)} g/m³</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="6.5"
              step="0.1"
              value={params.supercooledWater}
              onChange={(e) => updateParam('supercooledWater', parseFloat(e.target.value))}
              className="w-full accent-teal-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">
              * {params.supercooledWater > 3.0 ? '풍부 (투명 Glaze 층 성장)' : '부족 (불투명 Rime 층 위주)'}
            </span>
          </div>

          {/* Ice Nuclei Density */}
          <div className="flex flex-col gap-1.5">
            <span className="text-xs text-slate-300">빙결핵 밀도 (Ice Nuclei)</span>
            <div className="grid grid-cols-3 gap-1 mt-0.5">
              {(['low', 'normal', 'high'] as const).map((density) => (
                <button
                  key={density}
                  onClick={() => updateParam('iceNucleiDensity', density)}
                  className={`py-1 rounded text-[11px] font-semibold transition-colors border ${
                    params.iceNucleiDensity === density
                      ? 'bg-blue-600 border-blue-400 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {density === 'low' ? '희박 (대형)' : density === 'normal' ? '보통' : '과다 (소형)'}
                </button>
              ))}
            </div>
            <span className="text-[10px] text-slate-400">
              * 핵이 적을수록 단일 우박에 수분이 집중되어 거대화
            </span>
          </div>

          {/* Initial Embryo Size */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">초기 배아 직경 (Embryo Size)</span>
              <span className="font-mono font-bold text-slate-200">{params.initialEmbryoSizeMm.toFixed(1)} mm</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="5.0"
              step="0.5"
              value={params.initialEmbryoSizeMm}
              onChange={(e) => updateParam('initialEmbryoSizeMm', parseFloat(e.target.value))}
              className="w-full accent-slate-400 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
          </div>
        </div>

        {/* 3. WIND & DYNAMICS CONTROLS */}
        <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col gap-3.5">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <Wind className="w-4 h-4 text-purple-400" />
              3. 바람 & 기류 (Wind Dynamics)
            </span>
            <span className="text-[10px] text-purple-300 bg-purple-950/80 px-1.5 py-0.5 rounded border border-purple-800">
              부유·순환
            </span>
          </div>

          {/* Updraft Velocity */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">상승 기류 속도 (Updraft)</span>
              <span className="font-mono font-bold text-purple-300">{params.updraftVelocity} m/s</span>
            </div>
            <input
              type="range"
              min="10"
              max="65"
              step="1"
              value={params.updraftVelocity}
              onChange={(e) => updateParam('updraftVelocity', parseInt(e.target.value, 10))}
              className="w-full accent-purple-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
            <span className={`text-[10px] font-semibold ${updraftRating.color}`}>
              * {updraftRating.label} ({(params.updraftVelocity * 3.6).toFixed(0)} km/h)
            </span>
          </div>

          {/* Horizontal Wind / Wind Shear */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">수평 풍속 / 윈드시어 (Wind Shear)</span>
              <span className="font-mono font-bold text-pink-300">{params.horizontalWindSpeed} m/s</span>
            </div>
            <input
              type="range"
              min="0"
              max="45"
              step="1"
              value={params.horizontalWindSpeed}
              onChange={(e) => updateParam('horizontalWindSpeed', parseInt(e.target.value, 10))}
              className="w-full accent-pink-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">
              * 경사진 상승기류 형성으로 우박 다중 순환 유도
            </span>
          </div>

          {/* Turbulence Level */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">난류 강도 (Turbulence)</span>
              <span className="font-mono font-bold text-slate-300">Lv.{params.turbulence}</span>
            </div>
            <input
              type="range"
              min="1"
              max="5"
              step="1"
              value={params.turbulence}
              onChange={(e) => updateParam('turbulence', parseInt(e.target.value, 10))}
              className="w-full accent-slate-400 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">
              * 구름 내부 불규칙 궤적 및 횡방향 확산
            </span>
          </div>
        </div>

        {/* 4. ATMOSPHERIC PRESSURE & DENSITY */}
        <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col gap-3.5">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <Gauge className="w-4 h-4 text-amber-400" />
              4. 대기압 (Pressure)
            </span>
            <span className="text-[10px] text-amber-300 bg-amber-950/80 px-1.5 py-0.5 rounded border border-amber-800">
              공기밀도
            </span>
          </div>

          {/* Surface Pressure */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">지상 기압 (Surface Pressure)</span>
              <span className="font-mono font-bold text-amber-300">{params.surfacePressure} hPa</span>
            </div>
            <input
              type="range"
              min="950"
              max="1050"
              step="2"
              value={params.surfacePressure}
              onChange={(e) => updateParam('surfacePressure', parseInt(e.target.value, 10))}
              className="w-full accent-amber-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">
              * {params.surfacePressure < 1000 ? '저기압성 폭풍 조건' : '표준/고기압 조건'}
            </span>
          </div>

          {/* Real-time Computed Physical Indicators */}
          <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg flex flex-col gap-1.5 mt-1">
            <span className="text-[11px] font-bold text-slate-300">실시간 연동 대기 물리 지표</span>
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>지상 공기 밀도 (ρ_air):</span>
              <strong className="text-white font-mono">{estimatedAirDensity.toFixed(3)} kg/m³</strong>
            </div>
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>동결 성장대 두께:</span>
              <strong className="text-sky-300 font-mono">{(params.cloudTopAltitude - params.freezingLevel).toFixed(1)} km</strong>
            </div>
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>융해 위험도:</span>
              <strong className={`font-semibold ${meltingRisk.color}`}>{meltingRisk.label.split(' ')[0]}</strong>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
