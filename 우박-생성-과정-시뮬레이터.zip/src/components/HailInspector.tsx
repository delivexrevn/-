import React, { useState } from 'react';
import { HailSimulationResult, HailLayer } from '../types';
import { CircleDot, Info, Layers, Sparkles, Scale, Timer, ArrowDown, Droplets, Gauge, Zap, TrendingUp } from 'lucide-react';

interface HailInspectorProps {
  simResult: HailSimulationResult;
}

export const HailInspector: React.FC<HailInspectorProps> = ({ simResult }) => {
  const [selectedLayerId, setSelectedLayerId] = useState<string | null>(null);

  const { 
    finalDiameterMm, 
    maxDiameterMm, 
    finalMassG, 
    totalCycles, 
    totalDurationSec, 
    layers, 
    meltedLossPercentage, 
    sizeClassNameKo, 
    comparisonObjectKo,
    averageDensityGcm3,
    growthRateMmPerMin,
    impactImpulseNs,
    watermelonImpact
  } = simResult;
  const isMelted = finalDiameterMm <= 0;

  // Find selected layer or default to the outermost layer
  const activeLayer = layers.find((l) => l.id === selectedLayerId) || layers[layers.length - 1];

  // SVG Dimension params
  const svgSize = 340;
  const center = svgSize / 2;
  const maxRadiusMm = Math.max(1, maxDiameterMm / 2);
  const scaleRadius = (radiusMm: number) => {
    return Math.min(140, Math.max(8, (radiusMm / maxRadiusMm) * 140));
  };

  // Real world object references
  const comparisonItems = [
    { name: '완두콩', sizeMm: 8, label: '8mm' },
    { name: '100원 동전', sizeMm: 24, label: '24mm' },
    { name: '탁구공', sizeMm: 40, label: '40mm' },
    { name: '골프공', sizeMm: 43, label: '43mm' },
    { name: '야구공', sizeMm: 74, label: '74mm' },
    { name: '자몽', sizeMm: 110, label: '110mm' },
  ];

  return (
    <div className="flex flex-col gap-5 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl text-slate-200">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-sky-400" />
            우박 층상 구조 (양파 껍질 단면) 및 물리 특성 정밀 분석기
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            우박이 적란운 내를 순환하며 획득한 투명 얼음층(Glaze)과 불투명 백색층(Rime)의 동심원 구조 및 밀도·성장속도를 확인하세요.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs px-2.5 py-1 bg-slate-800 border border-slate-700 rounded-full font-medium text-slate-300">
            총 {layers.length}개 얼음층 누적
          </span>
        </div>
      </div>

      {isMelted ? (
        <div className="flex flex-col items-center justify-center p-8 bg-slate-950/60 border border-slate-800 rounded-xl text-center">
          <div className="w-14 h-14 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-3">
            <Droplets className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-white mb-1">지상 도달 전 빗방울로 전량 융해되었습니다</h3>
          <p className="text-xs text-slate-400 max-w-md leading-relaxed">
            상승 기류 속도가 부족하거나 지상 기온(0°C 동결고도)이 너무 높아, 구름 상층에서 형성된 우박 배아가 지상으로 떨어지는 과정에서 모두 녹아 소나기로 내렸습니다.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Left: Interactive Cross-Section SVG */}
          <div className="lg:col-span-7 flex flex-col items-center justify-center bg-slate-950/80 border border-slate-800 rounded-xl p-4 relative overflow-hidden">
            <span className="text-[11px] font-semibold text-slate-400 absolute top-3 left-4 flex items-center gap-1.5">
              <CircleDot className="w-3.5 h-3.5 text-sky-400" />
              양파 껍질 단면도 (클릭하여 층별 상세 정보 확인)
            </span>

            <svg
              width={svgSize}
              height={svgSize}
              viewBox={`0 0 ${svgSize} ${svgSize}`}
              className="my-2 cursor-pointer select-none"
            >
              <defs>
                {/* Glaze gradient */}
                <radialGradient id="glazeGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#bae6fd" stopOpacity="0.8" />
                  <stop offset="85%" stopColor="#38bdf8" stopOpacity="0.65" />
                  <stop offset="100%" stopColor="#0284c7" stopOpacity="0.9" />
                </radialGradient>
                {/* Rime gradient */}
                <radialGradient id="rimeGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#ffffff" stopOpacity="0.98" />
                  <stop offset="70%" stopColor="#f1f5f9" stopOpacity="0.95" />
                  <stop offset="100%" stopColor="#cbd5e1" stopOpacity="0.9" />
                </radialGradient>
              </defs>

              {/* Background grid markings */}
              <circle cx={center} cy={center} r={145} fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="4 4" />
              <circle cx={center} cy={center} r={100} fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="4 4" />
              <circle cx={center} cy={center} r={50} fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="4 4" />

              {/* Render concentric rings from outermost to innermost */}
              {layers
                .slice()
                .reverse()
                .map((layer) => {
                  const r = scaleRadius(layer.outerRadiusMm);
                  const isSelected = layer.id === activeLayer?.id;
                  const isRime = layer.type === 'rime';

                  return (
                    <g key={layer.id} onClick={() => setSelectedLayerId(layer.id)}>
                      <circle
                        cx={center}
                        cy={center}
                        r={r}
                        fill={isRime ? 'url(#rimeGrad)' : 'url(#glazeGrad)'}
                        stroke={isSelected ? '#f59e0b' : isRime ? '#ffffff' : '#0284c7'}
                        strokeWidth={isSelected ? 3 : 1.5}
                        className="transition-all hover:opacity-90"
                      />
                      {/* Frost texture line */}
                      {isRime && r > 20 && (
                        <circle
                          cx={center}
                          cy={center}
                          r={r - 3}
                          fill="none"
                          stroke="rgba(255,255,255,0.4)"
                          strokeWidth="1"
                          strokeDasharray="2 3"
                        />
                      )}
                    </g>
                  );
                })}

              {/* Center Embryo Label */}
              <text
                x={center}
                y={center + 3}
                textAnchor="middle"
                fontSize="9"
                fontWeight="bold"
                fill="#334155"
              >
                배아
              </text>

              {/* Diameter Arrow Annotation */}
              <line
                x1={center - scaleRadius(finalDiameterMm / 2)}
                y1={center}
                x2={center + scaleRadius(finalDiameterMm / 2)}
                y2={center}
                stroke="#f59e0b"
                strokeWidth="1.5"
                strokeDasharray="3 3"
              />
            </svg>

            {/* Legend & Diameter Callout */}
            <div className="flex items-center justify-between w-full px-2 pt-2 border-t border-slate-800/80 text-xs">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-slate-300">
                  <span className="w-3 h-3 rounded-full bg-slate-100 border border-slate-300 inline-block" />
                  불투명 백색층 (Rime, 밀도 ~0.78g/cm³)
                </span>
                <span className="flex items-center gap-1 text-slate-300">
                  <span className="w-3 h-3 rounded-full bg-sky-400 border border-sky-600 inline-block" />
                  투명 얼음층 (Glaze, 밀도 ~0.91g/cm³)
                </span>
              </div>
              <span className="font-mono font-bold text-amber-400">
                Ø {finalDiameterMm} mm
              </span>
            </div>
          </div>

          {/* Right: Selected Layer Deep Dive & Physical Stats */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {/* Selected Layer Info Card */}
            {activeLayer && (
              <div className="p-4 bg-slate-950/70 border border-amber-500/40 rounded-xl flex flex-col gap-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    {activeLayer.type === 'rime' ? '불투명 백색층 (Rime Layer)' : '투명 유리질층 (Glaze Layer)'}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                    제 {activeLayer.cycleNumber}차 순환
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-medium">
                  {activeLayer.description}
                </p>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-xs font-mono text-slate-400">
                  <div>
                    형성 고도: <strong className="text-sky-300">{activeLayer.formedAltitudeKm} km</strong>
                  </div>
                  <div>
                    형성 기온: <strong className="text-blue-300">{activeLayer.formedTempC} °C</strong>
                  </div>
                  <div>
                    층 두께: <strong className="text-emerald-300">+{activeLayer.thicknessMm} mm</strong>
                  </div>
                  <div>
                    층 밀도: <strong className="text-purple-300">{activeLayer.densityGcm3} g/cm³</strong>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Metrics Grid (6 boxes) */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-lg">
                <span className="text-[10px] text-slate-400 flex items-center gap-1 mb-1">
                  <Scale className="w-3 h-3 text-slate-400" />
                  최종 질량 (Mass)
                </span>
                <span className="text-sm font-bold text-white font-mono">
                  {finalMassG} g
                </span>
              </div>

              <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-lg">
                <span className="text-[10px] text-slate-400 flex items-center gap-1 mb-1">
                  <Gauge className="w-3 h-3 text-purple-400" />
                  우박 평균 밀도
                </span>
                <span className="text-sm font-bold text-purple-300 font-mono">
                  {averageDensityGcm3} g/cm³
                </span>
              </div>

              <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-lg">
                <span className="text-[10px] text-slate-400 flex items-center gap-1 mb-1">
                  <TrendingUp className="w-3 h-3 text-emerald-400" />
                  평균 성장 속도
                </span>
                <span className="text-sm font-bold text-emerald-300 font-mono">
                  {growthRateMmPerMin} mm/분
                </span>
              </div>

              <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-lg">
                <span className="text-[10px] text-slate-400 flex items-center gap-1 mb-1">
                  <Timer className="w-3 h-3 text-slate-400" />
                  순환 횟수 / 체류 시간
                </span>
                <span className="text-sm font-bold text-white font-mono">
                  {totalCycles}회 / {Math.floor(totalDurationSec / 60)}분 {totalDurationSec % 60}초
                </span>
              </div>

              <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-lg">
                <span className="text-[10px] text-slate-400 flex items-center gap-1 mb-1">
                  <ArrowDown className="w-3 h-3 text-rose-400" />
                  낙하 융해 손실
                </span>
                <span className="text-sm font-bold text-rose-400 font-mono">
                  {meltedLossPercentage}% 손실
                </span>
              </div>

              <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-lg">
                <span className="text-[10px] text-slate-400 block mb-1">
                  수박 파괴 지수
                </span>
                <span className="text-xs font-bold text-rose-400 block font-mono">
                  🍉 {watermelonImpact.watermelonsBroken}개 완파
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Real-World Size Comparison Bar */}
      {!isMelted && (
        <div className="flex flex-col gap-2 p-4 bg-slate-950/50 border border-slate-800 rounded-xl">
          <span className="text-xs font-bold text-slate-300">
            실물 사물 크기 직관 비교 (Scale Comparison)
          </span>
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            {comparisonItems.map((item) => {
              const isSmaller = finalDiameterMm >= item.sizeMm;
              return (
                <div
                  key={item.name}
                  className={`flex flex-col items-center p-2 rounded-lg border transition-all ${
                    isSmaller
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-300'
                      : 'bg-slate-900 border-slate-800 text-slate-500 opacity-60'
                  }`}
                >
                  <div
                    className="rounded-full bg-slate-700 mb-1.5 flex items-center justify-center border"
                    style={{
                      width: `${Math.max(14, Math.min(48, item.sizeMm * 0.55))}px`,
                      height: `${Math.max(14, Math.min(48, item.sizeMm * 0.55))}px`,
                    }}
                  />
                  <span className="text-[11px] font-bold">{item.name}</span>
                  <span className="text-[10px] font-mono">{item.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
