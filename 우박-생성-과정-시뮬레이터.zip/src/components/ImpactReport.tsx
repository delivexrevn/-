import React, { useState } from 'react';
import { HailSimulationResult } from '../types';
import { WatermelonSmash } from './WatermelonSmash';
import { 
  ShieldAlert, 
  Car, 
  Trees, 
  Building2, 
  UserX, 
  Gauge, 
  Activity, 
  AlertTriangle,
  Sparkles,
  CheckCircle,
  HelpCircle,
  Zap,
  Weight,
  Flame
} from 'lucide-react';

interface ImpactReportProps {
  simResult: HailSimulationResult;
}

export const ImpactReport: React.FC<ImpactReportProps> = ({ simResult }) => {
  const [impactTestTriggered, setImpactTestTriggered] = useState<boolean>(false);

  const { 
    finalDiameterMm, 
    finalMassG,
    terminalVelocityKmh, 
    impactEnergyJoules, 
    impactImpulseNs,
    impactPeakForceKn,
    averageDensityGcm3,
    damageLevel, 
    damageSummaryKo, 
    sizeClassNameKo,
    watermelonImpact
  } = simResult;
  
  const isMelted = finalDiameterMm <= 0;

  // TORRO Hail Scale estimation
  const getTorroScale = (diameterMm: number) => {
    if (diameterMm < 5) return { scale: 'H0', name: '무피해 (싸락눈)' };
    if (diameterMm < 10) return { scale: 'H1', name: '경미한 피해 (연약한 잎)' };
    if (diameterMm < 15) return { scale: 'H2', name: '가벼운 피해 (농작물 흠집)' };
    if (diameterMm < 20) return { scale: 'H3', name: '주의보급 (비닐하우스 손상)' };
    if (diameterMm < 30) return { scale: 'H4', name: '경보급 (차량 미세 함몰)' };
    if (diameterMm < 45) return { scale: 'H5', name: '파괴적 (차량 본넷 찌그러짐)' };
    if (diameterMm < 60) return { scale: 'H6', name: '중대 피해 (유리창 파손, 기와 파열)' };
    if (diameterMm < 75) return { scale: 'H7', name: '심각한 재난 (목재 관통, 차체 대파)' };
    if (diameterMm < 90) return { scale: 'H8', name: '극심한 재난 (슬레이트 지붕 파괴)' };
    return { scale: 'H9~H10', name: '초괴멸적 재난 (콘크리트 파손, 인명 치명타)' };
  };

  const torro = getTorroScale(finalDiameterMm);

  // Sector Impacts breakdown
  const getSectorImpacts = (diam: number) => {
    if (diam <= 0) {
      return {
        car: '피해 없음 (빗방울로 융해)',
        crop: '단비 (가뭄 해갈)',
        building: '피해 없음',
        human: '우산 필요 (단순 강우)',
      };
    }
    if (diam < 15) {
      return {
        car: '차량 피해 없음 (페인트 흠집 없음)',
        crop: '상추, 배추 등 연약 채소 잎 일부 찢어짐',
        building: '비닐하우스 비닐 미세 흠집',
        human: '맞으면 따끔거림, 우산으로 방어 가능',
      };
    }
    if (diam < 35) {
      return {
        car: '본넷 및 루프에 미세한 딤플(문콕 형태) 발생 가능',
        crop: '사과, 배 등 과수 낙과 및 껍질 타박상으로 상품 가치 급락',
        building: '노후 기와 파손, 비닐하우스 비닐 파열',
        human: '직격 시 찰과상 및 타박상 위험, 즉시 건물 내부 대피 필요',
      };
    }
    if (diam < 60) {
      return {
        car: '앞유리 및 뒷유리 금/파손, 본넷·도어 심각한 함몰 (수백만원 수리비)',
        crop: '과수원 및 노지 작물 80~100% 전손, 나뭇가지 부러짐',
        building: '선룸 유리창 및 태양광 패널 파열, 슬레이트 지붕 파손',
        human: '머리 직격 시 뇌진탕 및 두개골 골절 위험! 절대 야외 체류 금지',
      };
    }
    return {
      car: '차량 앞유리 완전 관통, 루프 뚫림, 전손(폐차) 판정 위험',
      crop: '농경지 초토화, 묘목 및 시설물 완전 파괴',
      building: '지붕 완파, 주택 창문 대량 파손, 외벽 단열재 훼손',
      human: '야외 보행자 직격 시 치명적 생명 위협 (헬멧으로도 방어 불가)',
    };
  };

  const sector = getSectorImpacts(finalDiameterMm);

  return (
    <div className="flex flex-col gap-6">
      {/* 1. Dedicated Watermelon Smash Simulation Arena */}
      <WatermelonSmash simResult={simResult} />

      {/* 2. Comprehensive Ground Hazard Report */}
      <div className="flex flex-col gap-5 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl text-slate-200">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              지상 충돌 역학 및 종합 피해 영향 평가 리포트
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              우박의 종단 낙하 속도(Terminal Velocity), 충격량(Impulse), 운동 에너지(Kinetic Energy)에 따른 분야별 피해를 분석합니다.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span
              className={`text-xs px-2.5 py-1 rounded-full font-bold border ${
                damageLevel === 'catastrophic'
                  ? 'bg-rose-600/20 text-rose-300 border-rose-500'
                  : damageLevel === 'severe'
                  ? 'bg-orange-600/20 text-orange-300 border-orange-500'
                  : damageLevel === 'moderate'
                  ? 'bg-amber-600/20 text-amber-300 border-amber-500'
                  : 'bg-emerald-600/20 text-emerald-300 border-emerald-500'
              }`}
            >
              {damageLevel === 'catastrophic'
                ? '🚨 재난급 피해'
                : damageLevel === 'severe'
                ? '⚠️ 경보급 중대 피해'
                : damageLevel === 'moderate'
                ? '⚡ 주의보급 피해'
                : '✅ 안전 / 경미'}
            </span>
          </div>
        </div>

        {/* Physics Metrics HUD (4 columns) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Terminal Velocity */}
          <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col justify-between">
            <span className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
              <Gauge className="w-4 h-4 text-sky-400" />
              지상 낙하 종단 속도
            </span>
            <div className="flex items-baseline gap-2 my-1">
              <span className="text-2xl font-black text-white font-mono">
                {terminalVelocityKmh}
              </span>
              <span className="text-xs text-slate-400 font-mono">km/h</span>
              <span className="text-xs text-slate-500 font-mono">
                ({(terminalVelocityKmh / 3.6).toFixed(1)} m/s)
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {terminalVelocityKmh > 120
                ? '고속열차/투수 강속구 속도로 지상 충돌'
                : terminalVelocityKmh > 70
                ? '고속도로 주행 차량 속도로 강타'
                : '비교적 완만한 낙하 속도'}
            </p>
          </div>

          {/* Impact Impulse */}
          <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col justify-between">
            <span className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
              <Zap className="w-4 h-4 text-amber-400" />
              충격량 (Impulse, J = m·v)
            </span>
            <div className="flex items-baseline gap-2 my-1">
              <span className="text-2xl font-black text-amber-400 font-mono">
                {impactImpulseNs}
              </span>
              <span className="text-xs text-slate-400 font-mono">N·s</span>
            </div>
            <p className="text-[11px] text-slate-400">
              우박 질량({finalMassG}g)과 종단속도의 곱
            </p>
          </div>

          {/* Kinetic Energy */}
          <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col justify-between">
            <span className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
              <Activity className="w-4 h-4 text-rose-400" />
              충격 운동 에너지 (Energy)
            </span>
            <div className="flex items-baseline gap-2 my-1">
              <span className="text-2xl font-black text-rose-400 font-mono">
                {impactEnergyJoules}
              </span>
              <span className="text-xs text-slate-400 font-mono">Joules (J)</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {impactEnergyJoules > 100
                ? '야구 배트 풀스윙 이상의 파괴력'
                : impactEnergyJoules > 14
                ? '수박을 일격에 두동강 내는 에너지'
                : '물체 파손 없는 미세 충격력'}
            </p>
          </div>

          {/* TORRO Scale */}
          <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col justify-between">
            <span className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
              <AlertTriangle className="w-4 h-4 text-purple-400" />
              TORRO 국제 우박 등급
            </span>
            <div className="flex items-baseline gap-2 my-1">
              <span className="text-2xl font-black text-purple-400 font-mono">
                {torro.scale}
              </span>
              <span className="text-xs text-slate-300 font-medium truncate">{torro.name}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              평균 밀도: {averageDensityGcm3} g/cm³
            </p>
          </div>
        </div>

        {/* 4 Impact Sectors Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* 1. Vehicles */}
          <div className="p-4 bg-slate-950/40 border border-slate-800 rounded-xl flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 shrink-0">
              <Car className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-white mb-0.5">자동차 및 수송 시설</span>
              <p className="text-xs text-slate-300 leading-relaxed">{sector.car}</p>
            </div>
          </div>

          {/* 2. Agriculture */}
          <div className="p-4 bg-slate-950/40 border border-slate-800 rounded-xl flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 shrink-0">
              <Trees className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-white mb-0.5">농작물 및 과수원</span>
              <p className="text-xs text-slate-300 leading-relaxed">{sector.crop}</p>
            </div>
          </div>

          {/* 3. Buildings */}
          <div className="p-4 bg-slate-950/40 border border-slate-800 rounded-xl flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 shrink-0">
              <Building2 className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-white mb-0.5">주택 및 건물 시설</span>
              <p className="text-xs text-slate-300 leading-relaxed">{sector.building}</p>
            </div>
          </div>

          {/* 4. Human Safety */}
          <div className="p-4 bg-slate-950/40 border border-slate-800 rounded-xl flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 shrink-0">
              <UserX className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-white mb-0.5">보행자 및 인명 안전 요령</span>
              <p className="text-xs text-slate-300 leading-relaxed">{sector.human}</p>
            </div>
          </div>
        </div>

        {/* Interactive Vehicle Damage Simulator Test */}
        {!isMelted && (
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 flex items-center gap-2">
                <Car className="w-4 h-4 text-sky-400" />
                차량 충격 가상 테스트기 (직경 {finalDiameterMm}mm 우박 충돌 시뮬레이션)
              </span>
              <button
                id="car-impact-test-btn"
                onClick={() => {
                  setImpactTestTriggered(true);
                  setTimeout(() => setImpactTestTriggered(false), 2500);
                }}
                className="px-3 py-1 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white rounded text-xs font-medium transition-colors"
              >
                우박 투하 테스트
              </button>
            </div>

            <div className="relative w-full h-36 bg-slate-900 border border-slate-800 rounded-lg overflow-hidden flex items-center justify-center">
              {/* SVG Car Illustration */}
              <svg
                width="260"
                height="90"
                viewBox="0 0 260 90"
                className={`transition-transform duration-200 ${impactTestTriggered ? 'animate-bounce' : ''}`}
              >
                {/* Car Body */}
                <path
                  d="M 20 60 L 50 60 L 75 35 L 180 35 L 210 60 L 240 60 C 248 60 252 65 252 70 L 252 75 L 8 75 L 8 70 C 8 65 12 60 20 60 Z"
                  fill="#3b82f6"
                  stroke="#1e3a8a"
                  strokeWidth="2"
                />
                {/* Windshield */}
                <polygon points="78,38 115,38 115,58 55,58" fill="#bae6fd" stroke="#0284c7" strokeWidth="1.5" />
                {/* Rear Window */}
                <polygon points="145,38 178,38 205,58 145,58" fill="#bae6fd" stroke="#0284c7" strokeWidth="1.5" />
                {/* Side Window */}
                <polygon points="118,38 142,38 142,58 118,58" fill="#bae6fd" stroke="#0284c7" strokeWidth="1.5" />

                {/* Wheels */}
                <circle cx="55" cy="75" r="14" fill="#0f172a" stroke="#475569" strokeWidth="3" />
                <circle cx="55" cy="75" r="6" fill="#94a3b8" />
                <circle cx="195" cy="75" r="14" fill="#0f172a" stroke="#475569" strokeWidth="3" />
                <circle cx="195" cy="75" r="6" fill="#94a3b8" />

                {/* Damage Cracks / Dents if large hail */}
                {finalDiameterMm >= 35 && (
                  <>
                    {/* Windshield spiderweb crack */}
                    <path d="M 85 46 L 75 42 M 85 46 L 95 40 M 85 46 L 82 54 M 85 46 L 92 53" stroke="#ffffff" strokeWidth="1.5" />
                    <circle cx="85" cy="46" r="3" fill="#ffffff" />
                  </>
                )}
                {finalDiameterMm >= 45 && (
                  <>
                    {/* Roof Dents */}
                    <ellipse cx="130" cy="36" rx="8" ry="3" fill="#1e3a8a" />
                    <ellipse cx="160" cy="36" rx="6" ry="2.5" fill="#1e3a8a" />
                    {/* Hood Dent */}
                    <ellipse cx="35" cy="62" rx="7" ry="3" fill="#1e3a8a" />
                  </>
                )}
              </svg>

              {/* Falling test hailstone animation */}
              {impactTestTriggered && (
                <div
                  className="absolute top-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-sky-200 rounded-full shadow-lg border border-white animate-ping"
                />
              )}
            </div>

            <p className="text-[11px] text-slate-400">
              * 직경 35mm 이상 시 전면유리 균열 발생, 45mm 이상 시 루프 및 본넷 다발성 함몰 발생.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
